# Laboratório de Estrutura de Dados II
Este repositório foi criado para a disciplina de Laboratório de Estrutura de Dados II do Curso de Ciência da Computação na Pontifícia Universidade Católica de Minas Gerais (PUCMG). Ele serve como um recurso central para os estudantes acessarem materiais didáticos, resolverem dúvidas e compartilharem conhecimentos relacionados ao curso.

## Contato
luizgomes@pucpcaldas.br

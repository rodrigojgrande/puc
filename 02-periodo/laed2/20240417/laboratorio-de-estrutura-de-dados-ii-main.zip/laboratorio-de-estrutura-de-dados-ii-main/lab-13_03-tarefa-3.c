/* Escreva uma fun¸c˜ao recursiva que dado dois n´umeros inteiros x e n, calcula o valor de xn.

eleva(x, 0) = 1
elava(x, n) = x * x ^ (n - 1)
*/
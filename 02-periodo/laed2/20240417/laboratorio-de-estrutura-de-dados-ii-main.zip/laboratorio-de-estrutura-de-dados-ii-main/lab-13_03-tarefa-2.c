/* 
Construa uma fun¸c˜ao recursiva em C que imprima o en´esimo n´umero de Fibonacci, sabendo que:
Fibonacci(0) = 0
Fibonacci(1) = 1
Fibonacci(n) = Fibonacci (n-1) + Fibonacci (n-2)
Exemplo de uma sequˆencia de Fibonacci: 0, 1, 1, 2, 3, 5, 8, 13, 21... Se a fun¸c˜ao for interrogada por
Fibonacci (6) o valor retornado dever´a ser 8.
*/